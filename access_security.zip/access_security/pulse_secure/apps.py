from django.apps import AppConfig


class PulseSecureConfig(AppConfig):
    name = 'pulse_secure'
