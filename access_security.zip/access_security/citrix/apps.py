from django.apps import AppConfig


class CitrixConfig(AppConfig):
    name = 'citrix'
