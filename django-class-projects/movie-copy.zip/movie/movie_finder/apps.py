from django.apps import AppConfig


class MovieFinderConfig(AppConfig):
    name = 'movie_finder'
